SZ22 Dataset


Samples:
(Cambridge Isotope Laboratories, Inc.; Catalog number: MSK-CRED-DD-KIT) 

- Unlabeled

12C_Ecoli_20220321_004.mzML                
12C_Ecoli_20220321_004_20220322130235.mzML 
12C_Ecoli_20220321_004_20220322095030.mzML 


- Labeled

13C_Ecoli_20220321_004_20220322101150.mzML
13C_Ecoli_20220321_004.mzML                
13C_Ecoli_20220321_004_20220322132355.mzML


Thermo Scientific Orbitrap ID-X Tribid Mass Spectrometer 
coupled to a Thermo Scientific Transcen LX-2 Duo UHPLC system, 
with a HESI ionization source, using positive ionization.
Reverse phase C18 column: Hypersil GOLDTM RP column (3 m, 2.1 mm x 50 mm).
Method file:
C:\Xcalibur\methods\MT\Metabolomics_Method\20210212_MT_RPpos60Kres5min

